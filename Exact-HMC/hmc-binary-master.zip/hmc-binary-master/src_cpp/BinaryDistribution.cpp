/* 
 * File:   BinaryDistribution.cpp
 * Author: aripakman
 * 
 * Created on May 8, 2013, 9:57 PM
 */

#include "BinaryDistribution.h"

BinaryDistribution::BinaryDistribution() {
}

BinaryDistribution::BinaryDistribution(const BinaryDistribution& orig) {
}

BinaryDistribution::~BinaryDistribution() {
}

