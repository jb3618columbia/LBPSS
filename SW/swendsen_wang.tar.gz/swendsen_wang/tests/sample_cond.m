function sample = sample_cond(cond_dist)
%function sample = sample_cond(cond_dist)
%sample = rand(size(cond_dist)) < cond_dist;

sample = rand(size(cond_dist)) < cond_dist;
